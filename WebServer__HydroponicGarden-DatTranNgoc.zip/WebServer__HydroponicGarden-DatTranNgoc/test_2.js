// if(navigator){
//     navigator.getBattery()
//     .then(status=>{
//         console.table(status);
//         Charging(status.charging);
//         BatteryLevel(status.level);

//         status.onchargingchange = ()=> Charging(status.charging);
//         status.onlevelchange = ()=>BatteryLevel(status.level);
//     })
// }else{
//     alert('Please full-filled');
// }

// let level = document.querySelector('.level');
// let text = document.querySelector('.text');
// function Charging(status)
// {
//     status ? level.classList.add('charging'):
//     level.classList.remove('charging');
// }

// function BatteryLevel(value)
// {
//     text.innerHTML =   `${value * 100}%`;
//     level.style.width = `${value * 100}%`;
// }

var value = $('.change').val()
if (value >= 0 || value <= 100) {
    $('.progress_inner').css("width", value + "%")
}

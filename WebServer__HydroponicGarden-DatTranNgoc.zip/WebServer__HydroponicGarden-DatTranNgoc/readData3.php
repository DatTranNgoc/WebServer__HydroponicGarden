<?php
header('Content-Type: application/json');
include("config.php");

$d4 = rand(10, 20);
$d5 = rand(0, 10);
// $d6 = 10;

$sql = "insert into parameters2(humid,ec) values ($d4,$d5)";
mysqli_query($conn,$sql);

$sql = "select * from parameters2 where stt>(select max(stt) from parameters2)-1";
$result = mysqli_query($conn,$sql);

$data = array();
foreach ($result as $row){
    $data[] = $row;
}

mysqli_close($conn);
echo json_encode($data);

?>
<?php
header('Content-Type: application/json');
include("config.php");

$d1 = rand(380, 780);
$d2 = rand(380, 780);
$d3 = rand(17, 45);
$d4 = rand(10, 20);
$d5 = rand(0, 10);

$sql = "insert into parameters(photopic,scopic,temp,humid,ec) values ($d1,$d2,$d3,$d4,$d5)";
mysqli_query($conn,$sql);

$sql = "select * from parameters where stt>(select max(stt) from parameters)-20";
$result = mysqli_query($conn,$sql);

$data = array();
foreach ($result as $row){
    $data[] = $row;
}

mysqli_close($conn);
echo json_encode($data);

?>
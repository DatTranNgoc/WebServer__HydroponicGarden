<?php
// Connect to database
$server = "localhost";
$username = "root"; 
$pass = "";
$dbname = "chart";

$conn = new mysqli($server,$username,$pass,$dbname);

// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}


?>